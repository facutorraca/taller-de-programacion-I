#ifndef _ANSWER_SERVER_H_
#define _ANSWER_SERVER_H_

#include "sudoku.h"

int answer_server_create(char* message, sudoku_t* sudoku);

#endif
